 void main() {
  operator
  relation > < >= <= == !=

  int a = 10;
  int b = 5;

  print(a > b); //true
  print(a < b); //false
  print(a >= b); //true
  print(a <= b); //false
  print(a == b); //false
  print(a != b); //true

  logical operators  And &&

  print('And operator \n');
  print(2 > 1 && 3 < 5);
  print(2 > 1 && 3 > 5);
  print(2 < 1 && 3 < 5);
  print(2 < 1 && 3 > 5);

  print(true && true);
  print(false && true);
  print(true && false);
  print(false && false);

  logical operators  Or ||

  print(true || true);
  print(false || true);
  print(true || false);
  print(false || false);
  print('Or operator \n');
  print(2 > 1 || 3 < 5);
  print(2 > 1 || 3 > 5);
  print(2 < 1 || 3 < 5);
  print(2 < 1 || 3 > 5);

//logical operators   !
  print('Not operator \n');
  print(!(2 > 4));
  print('Not operator \n');
  print(!true);
  print(!false);
greater than

  print(10 > 9);
  print(10 > 8);
  print(10 > 7);
  print(10 > 6);
  print(10 > 5);

  print(10 < 9);
  print(10 < 8);
  print(10 < 7);
  print(10 < 6);
  print(10 < 5);

  print(10 >= 9);
  print(10 >= 8);
  print(10 >= 7);
  print(10 >= 6);
  print(10 >= 5);

  print(10 <= 9);
  print(10 <= 8);
  print(10 <= 7);
  print(10 <= 6);
  print(10 <= 5);

  print(10 != 9);
  print(10 != 8);
  print(10 != 7);
  print(10 != 6);
  print(10 != 5);

  print(10 == 9);
  print(10 == 8);
  print(10 == 7);
  print(10 == 6);
  print(10 == 5);

  print(true && true);
  print(true && false);
  print(false && true);
  print(false && false);

  print(true || true);
  print(true || false);
  print(false || true);
  print(false || false);
  print(2 > 5 || 2 < 5);


  print(!true);
  print(!false);
  print(!(2 > 5));
  print(!(2 < 3));
}



// import 'dart:io';

// void main() {
// // condition      if  ,  if else  , else if

//   int a = 8;
//   if (a > 10) {
//     print('a is greater 10');
//   }

//   //if else

//   if (a > 10) {
//     print('a is greater than 10');
//   } else {
//     print('a is less than 10');
//   }

//   String email = 'abc@gmail.com';
//   String password = '12345678';

//   stdout.write('enter email   :');
//   String userEmail = stdin.readLineSync()!;

//   stdout.write('enter password   :');
//   String userPassword = stdin.readLineSync()!;

//   if (email == userEmail && password == userPassword) {
//     print('wellcome');
//   } else {
//     print('please enter right credential');
//   }
//   stdout.write('enter number   :');
//   var num1 = int.parse(stdin.readLineSync()!);
//   print(num1.runtimeType);
//   if (num1 % 2 == 0) {
//     print(' num1 is even number $num1');
//   } else {
//     print('num1 is odd number $num1');
//   }

// //typecasting

//   stdout.write('enter num1   :');
//   var num = int.parse(stdin.readLineSync()!);
//   stdout.write('enter num2  :');
//   var num2 = int.parse(stdin.readLineSync()!);
//   print(num1.runtimeType);
//   print(num1 + num2);
//   print(num1 - num2);
//   print(num1 / num2);
//   print(num1 * num2);
//   print(num);

//   var db_num1 = double.tryParse(stdin.readLineSync()!);
//   print(db_num1.runtimeType);
// }