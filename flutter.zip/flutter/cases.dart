void main() {
  // Snack case variables
  int my_first_variable = 10;
  String my_second_variable = "Hello";
  double my_third_variable = 3.14;
  bool my_fourth_variable = true;
  

  // Camel case variables
  int mySecondVariable = 20;
  String mySecondVariableString = "World";
  double myThirdVariableDouble = 6.28;
  bool myFourthVariableBoolean = false;
  

  // Pascal case variables
  int MyThirdVariable = 30;
  String MyThirdVariableString = "!";
  double MyFourthVariableDouble = 9.81;
  bool MyFifthVariableBoolean = true;
  

  // Print variables
  print("Snack Case Variables:");
  print("my_first_variable: $my_first_variable");
  print("my_second_variable: $my_second_variable");
  print("my_third_variable: $my_third_variable");
  print("my_fourth_variable: $my_fourth_variable");
  

  print("\nCamel Case Variables:");
  print("mySecondVariable: $mySecondVariable");
  print("mySecondVariableString: $mySecondVariableString");
  print("myThirdVariableDouble: $myThirdVariableDouble");
  print("myFourthVariableBoolean: $myFourthVariableBoolean");
  

  print("\nPascal Case Variables:");
  print("MyThirdVariable: $MyThirdVariable");
  print("MyThirdVariableString: $MyThirdVariableString");
  print("MyFourthVariableDouble: $MyFourthVariableDouble");
  print("MyFifthVariableBoolean: $MyFifthVariableBoolean");


}
