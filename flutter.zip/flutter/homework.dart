// import 'dart:io';

// void main() {
//   for (int a = 0; a <= 10; a++) {
//     stdout.write('$a  :');
//     for (int b = 0; b <= 10; b++) {
//       stdout.write(' $b ');
//     }
//     print('');
//   }

//   stdout.write('enter start table number    :');
//   int start = int.parse(stdin.readLineSync()!);
//   stdout.write('enter end table number    :');
//   int end = int.parse(stdin.readLineSync()!);

//   for (int a = start; a <= end; a++) {
//     for (int b = 0; b <= 10; b++) {
//       print('$a  * $b  = ${a * b} ');
//     }

//     print('\n\n\n');
//   }
// }

//import 'dart:io';

// void main() {
//   for (int a = 0; a < 10; a++) {
//     for (int b = 0; b < 10; b++) {
//       stdout.write(' * ');
//     }
//     print(''); // \n para que
//   }
//   print('');

//   for (int a = 0; a < 10; a++) {
//     for (int b = a; b < 10; b++) {
//       stdout.write(' * ');
//     }
//     print(''); // \n para que
//   }
//   print('');

//   for (int a = 0; a < 10; a++) {
//     for (int b = 0; b < a; b++) {
//       stdout.write(' * ');
//     }
//     print(''); // \n para que
//   }

//   for (int a = 0; a <= 10; a++) {
//     for (int b = a; b < 10; b++) {
//       stdout.write('   ');
//     }
//     for (int b = 0; b < a*2+1; b++) {
//        stdout.write(' * ');
//     }
   

//     print('');
//   }
// }

// import 'dart:io';

// void main() {
//   for (int a = 0; a <= 10; a++) {
//     for (int b = a; b < 10; b++) {
//       stdout.write('   ');
//     }
//     for (int b = 0; b < a * 2 + 1; b++) {
//       stdout.write(' * ');
//     }
//     stdout.write('\n');
//   }
//   for (int a = 9; a >= 0; a--) {
//     for (int b = a; b < 10; b++) {
//       stdout.write('   ');
//     }
//     for (int b = 0; b < a * 2 + 1; b++) {
//       stdout.write(' * ');
//     }
//     stdout.write('\n');
//   }
// }

void main() {
  // init
// while(codit){

// }

  int a = 0;
  while (a <= 10) {
    print(a);
    a++;
  }
  int b = 10;
  while (b >= 0) {
    print(b);
    b--;
  }
}



// import 'dart:io';

// void main() {
//   // for (int a = 0; a < 10; a++) {
//   //   for (int b = 0; b < 10; b++) {
//   //     stdout.write(' * ');
//   //   }
//   //   print(''); // \n para que
//   // }
//   print('');

//   for (int a = 0; a < 10; a++) {
//     for (int b = a; b < 10; b++) {
//       stdout.write(' * ');
//     }
//     print(''); // \n para que
//   }
//   print('');

//   for (int a = 0; a < 10; a++) {
//     for (int b = 0; b < a; b++) {
//       stdout.write(' * ');
//     }
//     print(''); // \n para que
//   }
  

//   for (int a = 0; a <= 10; a++) {
//     for (int b = a; b < 10; b++) {
//       stdout.write('   ');
//     }
//     for (int b = 0; b < a*2+1; b++) {
//        stdout.write(' * ');
//     }
//     print('');
//   }
// }