// void main() {
//   int myFirstVariable = 10;
//   String mySecondVariable = "Hello";
//   double myThirdVariable = 3.14;

//   int 1st_variable = 20; // Invalid
//   String my-second-variable = "World"; // Invalid
//   double my_third_variable@ = 6.28; // Invalid

//   print("Valid Identifiers:");
//   print("myFirstVariable: $myFirstVariable");
//   print("mySecondVariable: $mySecondVariable");
//   print("myThirdVariable: $myThirdVariable");

//   print("\nInvalid Identifiers:");
//   print("1st_variable: $1st_variable");
//   print("my-second-variable: $my-second-variable");
//   print("my_third_variable@: $my_third_variable@");
// }
