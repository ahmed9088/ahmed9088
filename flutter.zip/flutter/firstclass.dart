import 'dart:io';

void main() {
  // int num1 = 5, num2 = 10;
  // int sum = num1 + num2;
  // int difference = num1 - num2;
  // int product = num1 * num2;
  // double division = num1 / num2;
  // int modulus = num1 % num2;
  // print("Int Programs:");
  // print("Addition: $sum");
  // print("Subtraction: $difference");
  // print("Multiplication: $product");
  // print("Division: $division");
  // print("Modulus: $modulus");

  // double class1 = 10.10, class2 = 10.11;
  // double sumDouble = class1 + class2;
  // double differenceDouble = class1 - class2;
  // double productDouble = class1 * class2;
  // double divisionDouble = class1 / class2;
  // double remainder = class1 % class2;
  // print("\nDouble Programs:");
  // print("Addition (double): $sumDouble");
  // print("Subtraction (double): $differenceDouble");
  // print("Multiplication (double): $productDouble");
  // print("Division (double): $divisionDouble");
  // print("Remainder (double): $remainder");

  // String str1 = "Ahmed", str2 = "Memon";
  // String concat = str1 + " " + str2;
  // String substring = str1.substring(0, 3);
  // String uppercase = str2.toUpperCase();
  // String lowercase = str1.toLowerCase();
  // int length = str1.length;
  // print("\nString Programs:");
  // print("Concatenation: $concat");
  // print("Substring: $substring");
  // print("Uppercase: $uppercase");
  // print("Lowercase: $lowercase");
  // print("Length: $length");

  // bool a = true, b = false;
  // bool andResult = a && b;
  // bool orResult = a || b;
  // bool notResultA = !a, notResultB = !b;
  // bool equality = a == b;
  // print("\nBool Programs:");
  // print("Logical AND: $andResult");
  // print("Logical OR: $orResult");
  // print("Logical NOT A: $notResultA");
  // print("Logical NOT B: $notResultB");
  // print("Equality: $equality");

// condition      if  ,  if else  , else if

  int a = 8;
  // if (a > 10) {
  //   print('a is greater 10');
  // }

  //if else

  if (a > 10) {
    print('a is greater than 10');
  } else {
    print('a is less than 10');
  }

  String email = 'abc@gmail.com';
  String password = '12345678';
  String age = '20';
  stdout.write('enter email   :');
  String userEmail = stdin.readLineSync()!;

  stdout.write('enter password   :');
  String userPassword = stdin.readLineSync()!;
stdout.write('enter age   :');
String userAge = stdin.readLineSync()!;
  if (email == userEmail && password == userPassword && age == userAge) {
    print('wellcome');
  } else {
    print('please enter right credential');
  }
  stdout.write('enter number   :');
  var num1 = int.parse(stdin.readLineSync()!);
  print(num1.runtimeType);
  if (num1 % 2 == 0) {
    print(' num1 is even number $num1');
  } else {
    print('num1 is odd number $num1');
  }
}
